import java.io.Serializable;
import java.util.Calendar;
import java.util.Vector;


public class DayPlan implements Serializable
{
	private static final long serialVersionUID=1L;
	public Vector<Recipe> meals=new Vector<Recipe>(1);
	public Calendar day;
	public DayPlan(Calendar newDay)
	{
		day=newDay;
	}
}
