import java.io.Serializable;
import java.util.Calendar;
/**
 * @author Luke Senseney
 *
 */
public class WeekPlan implements Serializable
{
	private static final long serialVersionUID=1L;
	
	public DayPlan[] plans=new DayPlan[7];

	public Calendar firstDay;
	
	public WeekPlan(Calendar when)
	{
		firstDay=when;
		for(int i=0;i<7;i++)
		{
			Calendar next=(Calendar)firstDay.clone();
			next.add(Calendar.DAY_OF_MONTH,i);
			plans[i]=new DayPlan(next);
		}
	}
}
