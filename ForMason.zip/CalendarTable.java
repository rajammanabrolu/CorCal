private class CalendarTable extends JTable
{
    private static final long serialVersionUID=1L;
    private WeekPlan currentWeek;

    public CalendarTable(WeekPlan week)
    {
        super(new javax.swing.table.DefaultTableModel(1,7)
                {
                private static final long serialVersionUID=1L;

                @Override public String getColumnName(int column)
                {
                return dates.getWeekdays()[column+1];
                }
                });
        setDefaultRenderer(DayPlan.class,new RenderDayPlan());
        currentWeek=week;
    }

    @Override public TableCellRenderer getDefaultRenderer(Class<?> columnClass)
    {
        return new RenderDayPlan();
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.swing.table.TableModel#getValueAt(int, int)
     */
    @Override public Object getValueAt(int rowIndex,int columnIndex)
    {
        return currentWeek.plans[columnIndex];
    }

    public WeekPlan getWeek()
    {
        return currentWeek;
    }

    public void setWeek(WeekPlan week)
    {
        currentWeek=week;
        repaint();
    }

    private class RenderDayPlan extends JComponent implements TableCellRenderer
    {
        /**
         * 
         */
        private static final long serialVersionUID=1L;


        public RenderDayPlan(){}

        @Override public Component getTableCellRendererComponent(JTable table,Object value,boolean isSelected,boolean hasFocus,int row,int column)
        {
            DayPlan cell=(DayPlan)value;
            setLayout(new GridBagLayout());
            add(new JLabel(String.valueOf(cell.day.get(Calendar.DAY_OF_MONTH))),new GridBagConstraints(0,0,1,1,.01,1,GridBagConstraints.NORTHWEST,GridBagConstraints.NONE,new Insets(5,5,5,5),0,0));
            for(int i=0;i<cell.meals.size();i++)
            {
                add(new JLabel(cell.meals.get(i).name),new GridBagConstraints(1,i,1,1,1,1,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(5,0,5,0),0,0));
            }
            return this;
        }
    }
}
}
